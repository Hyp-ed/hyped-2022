#include <stdio.h>

int main() {
    (void)printf("Hello world!\n");
    x = 3 / 0; // ERROR
    return 0;
}

