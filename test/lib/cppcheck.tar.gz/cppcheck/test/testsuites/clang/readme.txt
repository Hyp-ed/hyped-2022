arrayIndexOutOfBounds:
~/llvm/tools/clang/test/Analysis/outofbound.c

